## Acknowledgments

This project uses [CamanJS](http://camanjs.com), an open-source JavaScript library for image editing, developed by Ryan LeFevre.  
CamanJS is licensed under the BSD 3-Clause License. You can find its license terms in the `LICENSE` file.
